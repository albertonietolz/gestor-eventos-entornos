package dao;

import modelo.Evento;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EventoDAO {
    private final String URL = "jdbc:mysql://localhost:3306/eventos_db";
    private final String USER = "root";
    private final String PASS = "";

    private Connection conectar() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    public void insertar(Evento evento) throws SQLException {
        String sql = "INSERT INTO eventos (nombre, fecha, lugar, descripcion) VALUES (?, ?, ?, ?)";
        try (Connection conn = conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, evento.getNombre());
            stmt.setDate(2, evento.getFecha());
            stmt.setString(3, evento.getLugar());
            stmt.setString(4, evento.getDescripcion());
            stmt.executeUpdate();
        }
    }

    public List<Evento> listar() throws SQLException {
        List<Evento> lista = new ArrayList<>();
        String sql = "SELECT * FROM eventos";
        try (Connection conn = conectar(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Evento e = new Evento(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getDate("fecha"),
                    rs.getString("lugar"),
                    rs.getString("descripcion")
                );
                lista.add(e);
            }
        }
        return lista;
    }

    public void actualizar(Evento evento) throws SQLException {
        String sql = "UPDATE eventos SET nombre = ?, fecha = ?, lugar = ?, descripcion = ? WHERE id = ?";
        try (Connection conn = conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, evento.getNombre());
            stmt.setDate(2, evento.getFecha());
            stmt.setString(3, evento.getLugar());
            stmt.setString(4, evento.getDescripcion());
            stmt.setInt(5, evento.getId());
            stmt.executeUpdate();
        }
    }

    public void eliminar(int id) throws SQLException {
        String sql = "DELETE FROM eventos WHERE id = ?";
        try (Connection conn = conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
}
