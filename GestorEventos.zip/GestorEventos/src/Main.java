import dao.EventoDAO;
import modelo.Evento;

import java.sql.Date;
import java.util.List;
import java.util.Scanner;

public class Main {
    static Scanner sc = new Scanner(System.in);
    static EventoDAO dao = new EventoDAO();

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n--- GESTOR DE EVENTOS ---");
            System.out.println("1. Listar eventos");
            System.out.println("2. Crear evento");
            System.out.println("3. Editar evento");
            System.out.println("4. Eliminar evento");
            System.out.println("0. Salir");
            System.out.print("Opción: ");
            int op = Integer.parseInt(sc.nextLine());

            try {
                switch (op) {
                    case 1 -> listar();
                    case 2 -> crear();
                    case 3 -> editar();
                    case 4 -> eliminar();
                    case 0 -> System.exit(0);
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static void listar() throws Exception {
        List<Evento> eventos = dao.listar();
        eventos.forEach(System.out::println);
    }

    private static void crear() throws Exception {
        System.out.print("Nombre: ");
        String nombre = sc.nextLine();
        System.out.print("Fecha (YYYY-MM-DD): ");
        Date fecha = Date.valueOf(sc.nextLine());
        System.out.print("Lugar: ");
        String lugar = sc.nextLine();
        System.out.print("Descripción: ");
        String descripcion = sc.nextLine();

        Evento e = new Evento(nombre, fecha, lugar, descripcion);
        dao.insertar(e);
        System.out.println("Evento creado.");
    }

    private static void editar() throws Exception {
        listar();
        System.out.print("ID del evento a editar: ");
        int id = Integer.parseInt(sc.nextLine());

        System.out.print("Nuevo nombre: ");
        String nombre = sc.nextLine();
        System.out.print("Nueva fecha (YYYY-MM-DD): ");
        Date fecha = Date.valueOf(sc.nextLine());
        System.out.print("Nuevo lugar: ");
        String lugar = sc.nextLine();
        System.out.print("Nueva descripción: ");
        String descripcion = sc.nextLine();

        Evento e = new Evento(id, nombre, fecha, lugar, descripcion);
        dao.actualizar(e);
        System.out.println("Evento actualizado.");
    }

    private static void eliminar() throws Exception {
        listar();
        System.out.print("ID del evento a eliminar: ");
        int id = Integer.parseInt(sc.nextLine());
        dao.eliminar(id);
        System.out.println("Evento eliminado.");
    }
}
