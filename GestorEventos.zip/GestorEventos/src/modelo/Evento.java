package modelo;

import java.sql.Date;

public class Evento {
    private int id;
    private String nombre;
    private Date fecha;
    private String lugar;
    private String descripcion;

    public Evento(int id, String nombre, Date fecha, String lugar, String descripcion) {
        this.id = id;
        this.nombre = nombre;
        this.fecha = fecha;
        this.lugar = lugar;
        this.descripcion = descripcion;
    }

    public Evento(String nombre, Date fecha, String lugar, String descripcion) {
        this(0, nombre, fecha, lugar, descripcion);
    }

    // Getters y setters

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public Date getFecha() { return fecha; }
    public String getLugar() { return lugar; }
    public String getDescripcion() { return descripcion; }

    public void setId(int id) { this.id = id; }

    @Override
    public String toString() {
        return id + " | " + nombre + " | " + fecha + " | " + lugar + " | " + descripcion;
    }
}
